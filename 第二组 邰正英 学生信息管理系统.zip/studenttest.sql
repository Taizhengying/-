/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.6.5-m8 : Database - studenttest
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`studenttest` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `studenttest`;

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `c_id` varchar(8) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `c_teacher` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `course` */

insert  into `course`(`c_id`,`c_name`,`c_teacher`) values ('1001','语文','李老师'),('1002','数学','唐老师'),('1003','英语','冯老师'),('1004','理综','刘老师');

/*Table structure for table `u_user` */

DROP TABLE IF EXISTS `u_user`;

CREATE TABLE `u_user` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_pwd` varchar(11) NOT NULL,
  `u_phone` varchar(11) NOT NULL,
  `u_role` int(11) NOT NULL,
  `u_isdelte` int(11) NOT NULL,
  `u_name` varchar(100) DEFAULT NULL,
  KEY `u_id` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1044 DEFAULT CHARSET=utf8;

/*Data for the table `u_user` */

insert  into `u_user`(`u_id`,`u_pwd`,`u_phone`,`u_role`,`u_isdelte`,`u_name`) values (1001,'a2','13160462500',0,0,'小明'),(1008,'a1','18975878601',2,0,'元朱严'),(1009,'a1','17862413890',1,0,'葛柳花'),(1033,'zhaosan','12345678910',1,0,'赵三'),(1036,'a2','12345678911',1,0,'赵四'),(1043,'11','99999999999',1,0,'赵启');

/*Table structure for table `userchoose` */

DROP TABLE IF EXISTS `userchoose`;

CREATE TABLE `userchoose` (
  `u_id` int(11) NOT NULL,
  `c_id` varchar(8) NOT NULL,
  `c_score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `userchoose` */

insert  into `userchoose`(`u_id`,`c_id`,`c_score`) values (1008,'1001',71),(1008,'1002',53),(1008,'1003',14),(1008,'1004',52),(1009,'1001',99),(1009,'1002',99),(1009,'1003',99),(1009,'1004',99),(1023,'1001',0),(1023,'1002',0),(1023,'1003',0),(1023,'1004',0),(1026,'1001',0),(1026,'1002',0),(1026,'1003',0),(1026,'1004',0),(1027,'1001',0),(1027,'1002',0),(1027,'1003',0),(1027,'1004',0),(1033,'1001',13),(1033,'1002',14),(1033,'1003',15),(1033,'1004',16),(1036,'1001',12),(1036,'1002',13),(1036,'1003',14),(1036,'1004',15),(1043,'1001',88),(1043,'1002',88),(1043,'1003',88),(1043,'1004',88);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
