package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.UserDao;
import entity.User;


@WebServlet(name = "LoginServlet",urlPatterns = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");//�����������


        String ID =request.getParameter("ID");//�����ò���
        String Password = request.getParameter("Password");//ͬ��
        String UserName =request.getParameter("UserName");


        if(ID.equals("")||Password.equals(""))
        {
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
        else{
            UserDao userdao = new UserDao();
            User u = userdao.login(ID,Password,UserName);//����dao�ж�����Ӧ�þ���������������
            if (u != null) {

                request.getSession().setAttribute("ID",ID);
                request.getSession().setAttribute("Password",Password);
                request.getSession().setAttribute("UserName",UserName);

                request.getRequestDispatcher("success.jsp").forward(request, response);
            } else {

                request.getRequestDispatcher("login.jsp").forward(request, response);//��¼����Ϣ����Ļ�����ת��ʧ�ܵĽ���
            }
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }//�� ��ҳ�л�ȡ����

}