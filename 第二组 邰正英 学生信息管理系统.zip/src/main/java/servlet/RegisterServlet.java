package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import entity.User;


@WebServlet(name = "RegisterServlet",urlPatterns = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    public RegisterServlet(){
        super();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("utf-8");//�����������
        request.setCharacterEncoding("utf-8");
        
        String ID= request.getParameter("ID");
        String Password=request.getParameter("Password");//�����ȡ����
        String Password1=request.getParameter("Password1");
        String UserName=request.getParameter("UserName");

        UserDao userdao=new UserDao();
        User u=userdao.search(ID);
       if(ID.equals("")||Password.equals("")||Password1.equals("")||UserName.equals("")||!Password.equals(Password1))
        {
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
       else{
           if(u!=null)
           {
               request.getRequestDispatcher("register.jsp").forward(request, response);
           }
           else{
        	   
        	   userdao.register(ID,Password,Password1,UserName);
               request.getRequestDispatcher("login.jsp").forward(request, response);//ע��ɹ�����ת����½����
           }
       }

    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}