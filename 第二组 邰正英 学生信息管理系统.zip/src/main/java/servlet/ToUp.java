package servlet;

import service.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ToUp
 */
@WebServlet("/upTo")
public class ToUp extends HttpServlet {
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String admId = req.getParameter("admId");
        String stuId = req.getParameter("stuId");
        /*
        * �����޸Ľ���
        *admId  stuId
        * */
        FileService fs = new FileServiceImpl();
        //�޸���ɼ����ؽ����Ƿ��ز�ͬ�Ľ���ģ�������Ҫ��ȡ����
        int role = fs.getAdmine(stuId).getRole();
        req.setAttribute("role",role);
        req.setAttribute("admId",admId);
        req.setAttribute("stuId",stuId);
        req.getRequestDispatcher("upPage.jsp").forward(req,resp);
    }
}
