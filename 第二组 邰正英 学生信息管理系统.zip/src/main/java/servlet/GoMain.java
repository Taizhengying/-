package servlet;

import service.*;
import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;

/**
 * Servlet implementation class GoMain
 */
@WebServlet("/goMain")
public class GoMain extends HttpServlet {
    /*
     * ����Ա����
     * ����ѧ��
     * */

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String admId = req.getParameter("admId");
        FileService fs = new FileServiceImpl();
        User user = fs.getAdmine(admId);

        //ʵ�ֵ�¼������ҵ���߼���
        FileService l = new FileServiceImpl();

        /*
         * ��ȡArr����
         * */
        System.out.println(user.getRole());
        List<User> arr = fs.getAllStudent();
        ArrayList<Major> studentUser = fs.getPersonFile(Integer.toString(user.getU_id()));
        if (user.getRole() == 0) {
            /*
             * ��ʦ
             * */

            req.setAttribute("user", user);
            req.setAttribute("arr", arr);
            req.getRequestDispatcher("mainPage.jsp").forward(req, resp);


        } else if (user.getRole() == 1) {
            /*
             * ѧ��
             * */
            req.setAttribute("user", user);
            req.setAttribute("arr", studentUser);
            req.getRequestDispatcher("StudentPage.jsp").forward(req, resp);
        } else if (user.getRole() == 2) {
            /*
             * ����Ա
             * */

            req.setAttribute("user", user);
            req.setAttribute("arr", arr);

            /*
             * ��ȡ���й���Ա
             * */

            req.getRequestDispatcher("admine.jsp").forward(req, resp);
        }

    }

}
