package servlet;

import service.*;
import java.util.ArrayList;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;

/**
 * Servlet implementation class ShowServlet
 */
@WebServlet("/show")
public class ShowServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        /*
        * ����ǲ鿴���˳ɼ�
        *
        * */
        String studentId = req.getParameter("v");
        FileService fs = new FileServiceImpl();
        ArrayList<Major> studentUser = fs.getPersonFile(studentId);
        req.setAttribute("arr",studentUser);
        req.getRequestDispatcher("scorePage.jsp").forward(req,resp);


    }

}
