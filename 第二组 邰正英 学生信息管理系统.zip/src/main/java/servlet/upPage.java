package servlet;

import service.*;
import java.util.ArrayList;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;

/**
 * Servlet implementation class upPage
 */
@WebServlet("/upStu")
public class upPage extends HttpServlet {
	@Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String admId = req.getParameter("admId");
        String stuId = req.getParameter("stuId");
        String a = req.getParameter("a");
        String b = req.getParameter("b");
        String c = req.getParameter("c");
        String d = req.getParameter("d");
        System.out.println(admId+"  "+stuId+"  "+a+"  "+b+" "+c+" "+d);
        FileService fs = new FileServiceImpl();
        fs.upScore(stuId,a,b,c,d);

        /*
        * �޸����ݹ������
        * �������ؾ��Ƿ���ǰ�˽���
        * */
        User user = fs.getAdmine(admId);
        ArrayList<User> arr = fs.getAllStudent();
        req.setAttribute("user",user);
        req.setAttribute("arr",arr);




        if(user.getRole()==0){
            /*
             * Ϊ��ʦ
             * */
            req.setAttribute("arr",arr);
            req.getRequestDispatcher("mainPage.jsp").forward(req,resp);
        }else if(user.getRole()==2){
            req.setAttribute("user",user);
            req.setAttribute("arr",arr);

            /*
             * ��ȡ���й���Ա
             * */

            req.getRequestDispatcher("admine.jsp").forward(req,resp);

        }
	}

}
