package servlet;

import service.*;
import java.util.ArrayList;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;

import java.util.List;
/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //window.location.href="update?upid="+upid+"&mainid=${mainid}&pwd="+pwd;
        String id=req.getParameter("upid");
        String mainid=req.getParameter("mainid");
        String pwd=req.getParameter("pwd");
        System.out.println(id+" "+mainid+" "+pwd);
        FileService fs = new FileServiceImpl();
        fs.uppwd(id,pwd);
        User user = fs.getAdmine(mainid);
        req.setAttribute("user",user);
        if(user.getRole()==0){
            /*
            * Ϊ��ʦ
            * */
            List<User> arr = fs.getAllStudent();
            req.setAttribute("arr",arr);
            req.getRequestDispatcher("mainPage.jsp").forward(req,resp);
        }else if(user.getRole()==1){
            ArrayList<Major> studentUser = fs.getPersonFile(Integer.toString(user.getU_id()));
            for(int i=0;i<studentUser.size();i++){
                System.out.println(studentUser.get(i).getA()+"  "+studentUser.get(i).getB());
            }
            req.setAttribute("arr",studentUser);
            req.getRequestDispatcher("StudentPage.jsp").forward(req,resp);
        }else if(user.getRole()==2){
            ArrayList<User> arr = fs.getAllStudent();
            req.setAttribute("user",user);
            req.setAttribute("arr",arr);

            /*
             * ��ȡ���й���Ա
             * */

            req.getRequestDispatcher("admine.jsp").forward(req,resp);

        }


    }
}
